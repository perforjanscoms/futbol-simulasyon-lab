const fs = require('fs'), vm = require('vm');
const path = require('path');
const dir = path.join(__dirname, '..') + '/';
const src = fs.readFileSync(dir + 'app.js', 'utf8');
const teams = JSON.parse(fs.readFileSync(dir + 'teams.json', 'utf8'));
const store = {};
const makeEl = (id) => {
  const el = { id, value: '', textContent: '', innerHTML: '', hidden: false, style: {}, dataset: {},
    classList: { add(){}, remove(){}, toggle(){} }, addEventListener(){}, focus(){}, scrollIntoView(){},
    append(){}, remove(){}, click(){}, setAttribute(){}, closest(){ return null; } };
  return el;
};
const els = {};
const doc = {
  getElementById: id => (els[id] ||= makeEl(id)),
  querySelectorAll: () => [],
  createElement: () => makeEl('x'),
  body: { append(){} },
};
const ctx = {
  document: doc, console, Math, JSON, Object, Array, Number, String, Date, Blob: class {}, URL: { createObjectURL(){return 'x'}, revokeObjectURL(){} },
  localStorage: { getItem: k => store[k] ?? null, setItem: (k,v) => { store[k] = v; }, removeItem: k => { delete store[k]; } },
  fetch: async () => ({ ok: true, json: async () => teams }),
  setTimeout: () => 0, clearTimeout(){}, window: { scrollTo(){} }, confirm: () => true, toast: null,
  Intl, encodeURIComponent,
};
ctx.window = ctx;
vm.createContext(ctx);
vm.runInContext(src, ctx);
const run = code => vm.runInContext(code, ctx);
const fails = [];
const check = (name, cond, extra='') => { console.log((cond ? 'OK   ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!cond) fails.push(name); };

setTimeout(() => {}, 0);
(async () => {
  await new Promise(r => setTimeout(r, 0));
  await new Promise(r => setImmediate(r));
  // 1. normalize: F, u, rakam ve aksan
  check('normalise Fenerbahçe', run("normalise('Fenerbahçe')") === 'fenerbahce');
  check('normalise Mardin 1969', run("normalise('Mardin 1969 Spor')") === 'mardin 1969 spor');
  check('teamByName ASCII girdi', run("teamByName('Fenerbahce') && teamByName('Fenerbahce').name") === 'Fenerbahçe');
  check('takım yüklendi', run('teams.length') === 655);
  // 2. varsayılan iki takım: uyarı + tek tip sonuç
  const r1 = run("buildModel(teamByName('Beşiktaş'), teamByName('Fenerbahçe'))");
  const r2 = run("buildModel(teamByName('Galatasaray'), teamByName('Trabzonspor'))");
  check('varsayılanlar aynı xG üretiyor (sorunun kökü)', Math.abs(r1.homeXg - r2.homeXg) < 1e-12 && Math.abs(r1.awayXg - r2.awayXg) < 1e-12, `xG ${r1.homeXg.toFixed(3)}-${r1.awayXg.toFixed(3)}`);
  check('uyarı çıkıyor (ikisi de veri yok)', run("dataWarning(teamByName('Beşiktaş'), teamByName('Fenerbahçe'))").includes('güç verisi girilmemiş'));
  // 3. olasılık toplamı
  const s = r1.hw + r1.d + r1.aw;
  check('1-X-2 toplamı = 1', Math.abs(s - 1) < 1e-9, s.toFixed(9));
  // 4. profil kaydı ve değişimin doğru takıma gitmesi
  run("$('homeTeam').value='Beşiktaş'; $('awayTeam').value='Fenerbahçe'; openEditor('home');");
  check('açılışta profil yazılmıyor', run("hasProfile('Beşiktaş')") === false);
  run("$('rating').value='1800'; onEditorInput();");
  check('düzenleme yalnız açık takıma yazılıyor', run("hasProfile('Beşiktaş') && !hasProfile('Fenerbahçe')"));
  run("$('awayTeam').value='Galatasaray'; $('rating').value='1600'; onEditorInput();");
  check('metin kutusu değişse de editingName korunuyor', run("hasProfile('Beşiktaş') && !hasProfile('Galatasaray')"));
  // 5. varsayılana dönünce kayıt silinir
  run("$('rating').value='1500'; onEditorInput();");
  check('varsayılana dönünce profil silinir', run("!hasProfile('Beşiktaş')"));
  // 6. güçlü/zayıf fark modelde yansıyor
  run("storeProfile('Beşiktaş',{rating:1900,attack:1.3,defense:0.9,form:2})");
  const r3 = run("buildModel(teamByName('Beşiktaş'), teamByName('Fenerbahçe'))");
  check('güçlü ev sahibi galibiyeti artıyor', r3.hw > r1.hw + 0.1, `${(r1.hw*100).toFixed(1)}% → ${(r3.hw*100).toFixed(1)}%`);
  check('uyarı tek takım için değişiyor', run("dataWarning(teamByName('Beşiktaş'), teamByName('Fenerbahçe'))").includes('Fenerbahçe için'));
  // 7. istatistik sonuçları sonlu ve makul
  const st = run("simulateStats(buildModel(teamByName('Beşiktaş'), teamByName('Fenerbahçe')), 'Beşiktaş', 'Fenerbahçe')");
  check('istatistik sonlu', Object.values(st).every(Number.isFinite));
  check('şut > isabetli şut', st.shotsH > st.onH && st.shotsA > st.onA, `${st.shotsH.toFixed(1)}>${st.onH.toFixed(1)}`);
  check('topla oynama toplamı 100', Math.abs(st.posH + st.posA - 100) < 1e-9);
  check('kırmızı kart ondalık gösterilebilir', st.redH >= 0 && st.redH < 1);
  // 8. CSV ayrıştırma (tırnaklı virgül + BOM)
  const parsed = run("parseCsv('\\uFEFFteam,type,rating\\n\"Galatasaray, Test\",club,1700\\nFenerbahçe,club,')");
  check('CSV tırnaklı virgül', parsed[0][0] === 'Galatasaray, Test' && parsed[0][1].rating === '1700', JSON.stringify(parsed[0][0]));
  check('CSV boş alan', parsed[1][1].rating === '');
  // 9. JSON içe aktarma biçimleri
  check('JSON profiles sarmalı', run("parseJson('{\"profiles\":{\"A\":{\"rating\":1600}}}')")[0][0] === 'A');
  let threw = false; try { run("parseJson('[1,2]')"); } catch { threw = true; }
  check('dizi JSON reddediliyor', threw);
  // 10. sınır değerler
  check('sanitize sınırı', run("sanitizeProfile({rating:99999,attack:-5,defense:0,form:99}).form") === 5);
  console.log(fails.length ? `\n${fails.length} test başarısız` : '\nTüm testler geçti');
  process.exit(fails.length ? 1 : 0);
})();
