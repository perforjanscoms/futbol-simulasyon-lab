# Değişiklik günlüğü

## 1.1.0

### Hatalar düzeltildi
- **Takım adı normalizasyonu bozuktu.** Regex `[\\u0300-\\u036f]` olarak yazılmıştı; bu, "F", "U" harflerini, rakamları ve bazı noktalama işaretlerini siliyordu ("Fenerbahçe" → "enerbahçe", "Mardin 1969 Spor" → "mardin  spor") ve aksanları kaldırmıyordu. Artık `[\u0300-\u036f]`.
- **Düzenleyici yanlış takıma yazabiliyordu.** Düzenleyici açıkken ev sahibi/deplasman metin kutusu değiştirilirse, kaydırıcı hareketleri açık olmayan takıma profil yazıyordu. Artık düzenlenen takım açılış anında sabitlenir.
- **Açılışta profil kaydediliyordu.** Düzenleyici açılınca her takım için varsayılan profil yazılıyordu. Artık yalnızca kullanıcı değer değiştirdiğinde ve varsayılandan farklıysa kaydedilir.
- **İstatistik çubukları yanlış renkteydi.** Deplasman tarafının dolu kısmı ev sahibi rengiyle çiziliyordu. Tek bir çubuk, iki takımın payını ayrı renklerle gösterir.
- **Kırmızı kart "0.0" gösteriyordu.** Kırmızı kart ortalaması 3 ondalıkla gösterilir.
- **Büyük/küçük harf ve aksan karşılaştırması** "Fenerbahce" gibi ASCII yazımla da takımı bulur.
- **Dışa aktarma bağlantısı** hemen iptal edilmiyor, tarayıcıların indirmeyi başlatması için 1 saniye bekleniyor.
- **localStorage hataları** (dolu ya da kapalı depolama) artık sessizce yutulmak yerine bildiriliyor.
- **CSV içe aktarma** BOM karakterini ve tırnak içindeki virgülleri doğru işler; boş alanlar varsayılan değer alır.

### Model ve arayüz
- Veri uyarısı: iki takımın da güç verisi yoksa sonucun üstünde açık bir uyarı çıkar. Tek takım için de uyarı verilir.
- Kaydırıcı değişince açık sonuç otomatik yeniden hesaplanır.
- İstatistik bölümü "Simüle edilen" yerine "Tahmini ortalamalar" olarak etiketlendi; gerçek maç verisi olmadığı açıkça yazılıyor.
- Model katsayıları değiştirilmedi (lig ortalaması 1.38/1.12, ev avantajı 1.09). Bu nedenle aynı girdilerle sonuçlar öncekiyle aynıdır.
- CSV güç şablonu eklendi (`ratings-template.csv`).

### Repo
- `build.py` kaldırıldı. Eski betik `index.html`, `app.js`, `style.css` ve README'yi yeniden yazıyordu, yani düzeltmeleri ezebiliyordu. Yerine `scripts/make_template.py` geldi.
- `tests/app.test.js` eklendi (22 kontrol).
