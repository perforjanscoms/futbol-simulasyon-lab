# Futbol Simülasyon Laboratuvarı

SanalMaç'ın herkese açık takım havuzundaki isimleri kullanan, bağımsız ve mobil uyumlu bir futbol karşılaştırma ve olasılık hesaplama uygulaması. Kaynak sitenin kodu, markası veya kapalı algoritması kopyalanmamıştır.

## Kapsam

- 446 kulüp ve 209 milli takım (kaynak listesinde görünen 655 kayıt).
- Takım arama, kulüp/milli filtresi, ev sahibi ve deplasman seçimi.
- Takım başına rating, hücum, savunma ve form değerlerini düzenleme.
- Poisson dağılımıyla 1-X-2 olasılıkları, beklenen gol (xG), 2.5 üst ve en olası skorlar.
- Hücum ve savunma çarpanlarıyla birlikte, sezgisel ortalamalara dayalı şut, korner, faul ve kart tahminleri.
- Veri veren takım uyarısı: güç verisi girilmemiş takımlar için sonucun yanında açık bir uyarı çıkar.
- Tarayıcıda saklama; JSON ve CSV ile içe ve dışa aktarma.

## Çalıştırma

Dosyayı `file://` ile açmak yerine bir web sunucusu kullanın (takım listesi `fetch` ile yüklenir):

```bash
python -m http.server 8000
```

Ardından `http://localhost:8000` adresini açın. GitHub Pages üzerinde doğrudan çalışır.

## Güç verisi nasıl girilir

Varsayılanda tüm takımların hücum ve savunma değeri 1.00, rating 1500 ve form 0'dır. Bu değerler birbirinin aynısı olduğu için **iki takımın da verisi yoksa her eşleşme aynı sonucu verir.** Uygulama bunu sonucun üstünde uyarı olarak gösterir.

Gerçek fark için iki yol var:

1. **Toplu:** `ratings-template.csv` dosyasını indirin (ya da `python3 scripts/make_template.py` ile yeniden üretin), doldurun, sonra "Veri içe aktar" ile yükleyin. Boş alan varsayılan değer alır.
2. **Tek tek:** Takımı seçin, "Gücü düzenle" ile kaydırıcıları ayarlayın. Değerler yalnızca bu tarayıcıda saklanır.

Değer aralıkları: rating 900–2200, hücum ve savunma 0.65–1.55, form -5 ile +5.

## Modelin sınırları

SanalMaç'ın herkese açık sayfaları Poisson dağılımı ve SM Rating adlarını anıyor ama katsayılarını, ham veriyi ya da kalibrasyon setini açıklamıyor. Bu proje özel bir algoritmanın kopyası değildir; şeffaf ve değiştirilebilir bir Poisson + rating yaklaşımıdır.

- Rating farkı modelde üstel olarak etki eder. 1500 ile 1900 arasındaki fark bile ev sahibi galibiyet olasılığını belirgin biçimde değiştirir; değerleri dikkatli girin.
- Şut, korner, faul ve kart sayıları gerçek maç verisi değildir. Model beklentilerinden türetilen sezgisel ortalamalardır ve arayüzde bu şekilde etiketlenmiştir.
- Model bağımsız Poisson varsayar; düşük skor korelasyonu için Dixon-Coles düzeltmesi yoktur.
- Sonuçlar tahmindir ve bahis tavsiyesi değildir.

## Dosyalar

- `index.html`, `style.css`, `app.js`: uygulamanın kendisi, derleme adımı yoktur.
- `teams.json`: 655 takım (ad ve tür).
- `ratings-template.csv`: güç giriş şablonu. `scripts/make_template.py` ile yeniden üretilebilir.
- `tests/app.test.js`: model, normalizasyon, CSV/JSON ayrıştırma ve profil davranışı için testler. Çalıştırma: `node tests/app.test.js`.

## Kaynak ve tarih

Takım adları `https://sanalmac.com/takimlar/` herkese açık listesinden derlenmiştir (9 Kasım 2026 tarihinde görüntülendi). Site giriş ekranında 700+ takım ifadesi kullanıyor; ancak bu tarihte listede 446 kulüp ve 209 milli takım, toplam 655 bağlantı görünüyordu. Bazı adların yazımı (ör. "Bröndby IF", "Bodo Glimt", "West Bromwich") düzeltilmeye ihtiyaç duyabilir; liste kaynakla tek tek karşılaştırılmadı.
