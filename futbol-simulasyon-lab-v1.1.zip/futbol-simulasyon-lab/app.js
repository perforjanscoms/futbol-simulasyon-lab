/* Futbol Simülasyon Laboratuvarı — uygulama mantığı
   Model: bağımsız Poisson + rating/hücum/savunma/form çarpanları.
   Gerçek maç verisi kullanılmaz; güç değerleri kullanıcı tarafından girilir. */

const SIMULATIONS = 20000;
const PROFILE_KEY = 'futbolLabProfiles';
const DEFAULT_PROFILE = Object.freeze({ rating: 1500, attack: 1, defense: 1, form: 0 });
const HOME_ADVANTAGE = 1.09;
const BASE_HOME_XG = 1.38;
const BASE_AWAY_XG = 1.12;
const MAX_GOALS = 8;

let teams = [];
let selectedType = 'club';
let listFilter = 'all';
let editingSide = 'home';
let editingName = null;
let activeTarget = 'awayTeam';
let profiles = loadProfiles();

const $ = id => document.getElementById(id);
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

/* ---------- Kalıcı profiller (yalnızca bu tarayıcıda) ---------- */

function loadProfiles() {
  try {
    const d = JSON.parse(localStorage.getItem(PROFILE_KEY) || '{}');
    return d && typeof d === 'object' && !Array.isArray(d) ? d : {};
  } catch {
    return {};
  }
}

function saveProfiles() {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profiles));
  } catch {
    toast('Tarayıcı depolamasına yazılamadı. Değişiklik bu oturumda geçerli, sayfa yenilenince kaybolur.');
  }
}

function sanitizeProfile(p = {}) {
  return {
    rating: clamp(Number(p.rating) || DEFAULT_PROFILE.rating, 900, 2200),
    attack: clamp(Number(p.attack) || 1, 0.65, 1.55),
    defense: clamp(Number(p.defense) || 1, 0.65, 1.55),
    form: clamp(Math.round(Number(p.form) || 0), -5, 5)
  };
}

function isDefaultProfile(p) {
  return p.rating === DEFAULT_PROFILE.rating && p.attack === 1 && p.defense === 1 && p.form === 0;
}

function hasProfile(name) {
  return Object.prototype.hasOwnProperty.call(profiles, name);
}

function profile(name) {
  return hasProfile(name) ? { ...DEFAULT_PROFILE, ...profiles[name] } : { ...DEFAULT_PROFILE };
}

// Varsayılan değerlerle aynıysa kayıt tutulmaz; böylece hasProfile "gerçek veri girildi" anlamına gelir.
function storeProfile(name, raw) {
  const clean = sanitizeProfile(raw);
  if (isDefaultProfile(clean)) delete profiles[name];
  else profiles[name] = clean;
}

/* ---------- Metin yardımcıları ---------- */

// Türkçe büyük/küçük harf ve aksan farkını yok sayan karşılaştırma anahtarı.
function normalise(s) {
  return (s || '').toLocaleLowerCase('tr').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
}

function teamByName(name) {
  const key = normalise(name);
  return teams.find(t => normalise(t.name) === key);
}

function teamById(name) {
  return teams.find(t => t.name === name);
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function toast(msg) {
  let n = $('toast');
  if (!n) {
    n = document.createElement('div');
    n.id = 'toast';
    n.className = 'toast';
    n.setAttribute('role', 'status');
    document.body.append(n);
  }
  n.textContent = msg;
  n.classList.add('show');
  clearTimeout(n._timer);
  n._timer = setTimeout(() => n.classList.remove('show'), 3000);
}

/* ---------- Başlangıç ---------- */

async function init() {
  try {
    const r = await fetch('./teams.json');
    if (!r.ok) throw new Error('teams.json okunamadı');
    teams = await r.json();
  } catch {
    $('teamCount').textContent = 'Takım verisi yüklenemedi';
    toast('Uygulamayı bir web sunucusu üzerinden açın (ör. GitHub Pages). file:// ile açıldığında veri yüklenmez.');
    return;
  }

  $('teamCount').textContent = `${teams.length} takım`;
  $('teamNames').innerHTML = teams.map(t => `<option value="${escapeHtml(t.name)}"></option>`).join('');

  document.querySelectorAll('.tab[data-type]').forEach(b => b.addEventListener('click', () => {
    selectedType = b.dataset.type;
    document.querySelectorAll('.tab[data-type]').forEach(x => x.classList.toggle('active', x === b));
    const list = teams.filter(t => t.type === selectedType);
    $('homeTeam').value = list[0]?.name || '';
    $('awayTeam').value = list[1]?.name || '';
    refreshTeamLabels();
  }));

  document.querySelectorAll('.tab[data-filter]').forEach(b => b.addEventListener('click', () => {
    listFilter = b.dataset.filter;
    document.querySelectorAll('.tab[data-filter]').forEach(x => x.classList.toggle('active', x === b));
    renderTeamChips();
  }));

  $('teamSearch').addEventListener('input', renderTeamChips);
  $('homeTeam').addEventListener('focus', () => (activeTarget = 'homeTeam'));
  $('awayTeam').addEventListener('focus', () => (activeTarget = 'awayTeam'));
  $('homeTeam').addEventListener('change', refreshTeamLabels);
  $('awayTeam').addEventListener('change', refreshTeamLabels);

  $('simulateBtn').addEventListener('click', () => runMatch({ scroll: true }));
  $('rerunBtn').addEventListener('click', () => runMatch({ scroll: true }));
  $('swapBtn').addEventListener('click', () => {
    const a = $('homeTeam').value;
    $('homeTeam').value = $('awayTeam').value;
    $('awayTeam').value = a;
    refreshTeamLabels();
    runMatch({ scroll: true });
  });

  document.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => openEditor(b.dataset.edit)));
  $('closeEditor').addEventListener('click', () => ($('editor').hidden = true));
  ['rating', 'attack', 'defense', 'form'].forEach(id => $(id).addEventListener('input', onEditorInput));
  $('resetProfile').addEventListener('click', () => {
    if (!editingName) return;
    setEditorValues(DEFAULT_PROFILE);
    onEditorInput();
    toast('Takım varsayılan değerlere döndürüldü.');
  });

  $('exportBtn').addEventListener('click', exportData);
  $('importFile').addEventListener('change', importData);

  $('teamChips').addEventListener('click', e => {
    const b = e.target.closest('[data-team]');
    if (!b) return;
    const t = teamByName(b.dataset.team);
    if (!t) return;
    $(activeTarget).value = t.name;
    refreshTeamLabels();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  refreshTeamLabels();
  renderTeamChips();
}

/* ---------- Takım listesi ---------- */

function refreshTeamLabels() {
  for (const side of ['home', 'away']) {
    const t = teamByName($(side + 'Team').value);
    $(side + 'Type').textContent = t ? (t.type === 'club' ? 'Kulüp takımı' : 'Milli takım') : 'Listede bulunamadı';
  }
}

function renderTeamChips() {
  const q = normalise($('teamSearch').value);
  const rows = teams.filter(t =>
    (listFilter === 'all' || t.type === listFilter) && (!q || normalise(t.name).includes(q)));
  const shown = rows.slice(0, 120);
  $('teamChips').innerHTML = shown.map(t =>
    `<button class="team-chip" data-team="${escapeHtml(t.name)}">${escapeHtml(t.name)}</button>`).join('');
  $('listFooter').textContent = rows.length > 120
    ? `${rows.length} eşleşme bulundu · İlk 120 takım gösteriliyor. Aramayı daralt.`
    : `${rows.length} takım gösteriliyor.`;
}

/* ---------- Güç düzenleyici ---------- */

function setEditorValues(p) {
  $('rating').value = p.rating;
  $('attack').value = p.attack;
  $('defense').value = p.defense;
  $('form').value = p.form;
}

function openEditor(side) {
  const t = teamByName($(side + 'Team').value);
  if (!t) {
    toast('Önce listeden bir takım seçin.');
    return;
  }
  editingSide = side;
  editingName = t.name;
  $('editorTitle').textContent = `${t.name} · ${side === 'home' ? 'Ev sahibi' : 'Deplasman'}`;
  setEditorValues(profile(t.name));
  updateEditorOutput();
  $('editor').hidden = false;
  $('editor').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Yalnızca etiketleri günceller; profil kaydetmez.
function updateEditorOutput() {
  const form = Number($('form').value);
  $('ratingOut').textContent = $('rating').value;
  $('attackOut').textContent = Number($('attack').value).toFixed(2) + '×';
  $('defenseOut').textContent = Number($('defense').value).toFixed(2) + '×';
  $('formOut').textContent = form > 0 ? '+' + form : String(form);
}

// Kullanıcı kaydırıcıyı hareket ettirdiğinde, düzenlenen takımın (açılış anındaki) profilini kaydeder.
function onEditorInput() {
  updateEditorOutput();
  if (!editingName) return;
  storeProfile(editingName, {
    rating: $('rating').value,
    attack: $('attack').value,
    defense: $('defense').value,
    form: $('form').value
  });
  saveProfiles();
  if (!$('results').hidden) runMatch({ scroll: false, silent: true });
}

/* ---------- Model ---------- */

function poisson(lambda, k) {
  let p = Math.exp(-lambda);
  for (let i = 1; i <= k; i++) p *= lambda / i;
  return p;
}

function buildModel(home, away) {
  const hp = profile(home.name);
  const ap = profile(away.name);
  const ratingDelta = (hp.rating - ap.rating) / 850;
  const formDelta = (hp.form - ap.form) * 0.035;

  const homeXg = clamp(BASE_HOME_XG * Math.exp(ratingDelta + formDelta) * hp.attack * ap.defense * HOME_ADVANTAGE, 0.15, 4.5);
  const awayXg = clamp(BASE_AWAY_XG * Math.exp(-ratingDelta - formDelta) * ap.attack * hp.defense, 0.15, 4.5);

  const ph = Array.from({ length: MAX_GOALS + 1 }, (_, k) => poisson(homeXg, k));
  const pa = Array.from({ length: MAX_GOALS + 1 }, (_, k) => poisson(awayXg, k));

  const matrix = [];
  let total = 0, hw = 0, d = 0, aw = 0, over25 = 0;
  for (let i = 0; i <= MAX_GOALS; i++) {
    matrix[i] = [];
    for (let j = 0; j <= MAX_GOALS; j++) {
      const p = ph[i] * pa[j];
      matrix[i][j] = p;
      total += p;
      if (i > j) hw += p;
      else if (i === j) d += p;
      else aw += p;
      if (i + j >= 3) over25 += p;
    }
  }
  // 0–8 dışındaki kuyruk küçük olduğu için tüm olasılıkları toplamla normalize ediyoruz.
  hw /= total; d /= total; aw /= total; over25 /= total;

  const scores = [];
  for (let i = 0; i <= MAX_GOALS; i++) {
    for (let j = 0; j <= MAX_GOALS; j++) {
      scores.push({ score: `${i}-${j}`, p: matrix[i][j] / total });
    }
  }
  scores.sort((x, y) => y.p - x.p);

  return { hp, ap, homeXg, awayXg, hw, d, aw, over25, scores, homeAdv: HOME_ADVANTAGE };
}

// Tekrarlanabilir sezgisel ortalamalar (şut, korner, faul, kart). Gerçek maç verisi değildir.
function seededRandom(seed) {
  let x = seed >>> 0;
  return () => {
    x = (x + 0x6d2b79f5) >>> 0;
    let t = x;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Knuth yöntemi: Poisson örneği. Üst sınır sonsuz döngüyü engeller.
function samplePoisson(lambda, rng) {
  const limit = Math.exp(-lambda);
  let k = 0, p = 1;
  do {
    k++;
    p *= rng();
  } while (p > limit && k < 40);
  return k - 1;
}

function simulateStats(m, homeName, awayName) {
  const seed = [...(homeName + '|' + awayName)].reduce((a, c) => (Math.imul(a, 31) + c.charCodeAt(0)) >>> 0, 2166136261);
  const rng = seededRandom(seed);
  const possession = clamp(50 + (m.hp.rating - m.ap.rating) / 35 + 4, 35, 65);
  const sums = { posH: 0, shotsH: 0, shotsA: 0, onH: 0, onA: 0, cornersH: 0, cornersA: 0, foulsH: 0, foulsA: 0, yellowH: 0, yellowA: 0, redH: 0, redA: 0 };

  for (let i = 0; i < SIMULATIONS; i++) {
    const jitter = () => 0.86 + rng() * 0.28;
    const sh = samplePoisson((8.8 + m.homeXg * 2.2) * jitter(), rng);
    const sa = samplePoisson((8.4 + m.awayXg * 2.2) * jitter(), rng);
    sums.posH += clamp(possession + (rng() - 0.5) * 14, 25, 75);
    sums.shotsH += sh;
    sums.shotsA += sa;
    sums.onH += Math.min(sh, samplePoisson(m.homeXg * 2.3 + 1.1, rng));
    sums.onA += Math.min(sa, samplePoisson(m.awayXg * 2.3 + 1.1, rng));
    sums.cornersH += samplePoisson(4.2 + m.homeXg * 0.55, rng);
    sums.cornersA += samplePoisson(4.0 + m.awayXg * 0.55, rng);
    sums.foulsH += samplePoisson(11.4, rng);
    sums.foulsA += samplePoisson(12.0, rng);
    sums.yellowH += samplePoisson(1.65, rng);
    sums.yellowA += samplePoisson(1.8, rng);
    sums.redH += rng() < 0.045 ? 1 : 0;
    sums.redA += rng() < 0.05 ? 1 : 0;
  }
  for (const k of Object.keys(sums)) sums[k] /= SIMULATIONS;
  return { ...sums, posA: 100 - sums.posH };
}

/* ---------- Eşleşme akışı ---------- */

function selectedPair(silent) {
  const h = teamByName($('homeTeam').value);
  const a = teamByName($('awayTeam').value);
  const fail = msg => { if (!silent) toast(msg); return null; };
  if (!h || !a) return fail('İki takımı da takım listesinden seçin.');
  if (h.name === a.name) return fail('Aynı takım kendisiyle eşleşemez.');
  if (h.type !== a.type) return fail('Kulüp takımları ile milli takımları aynı maçta eşleştirmeyin.');
  return { h, a };
}

function runMatch({ scroll = true, silent = false } = {}) {
  const pair = selectedPair(silent);
  if (!pair) return;
  const { h, a } = pair;
  const m = buildModel(h, a);
  const s = simulateStats(m, h.name, a.name);
  renderResult({ h, a, m, s });
  $('results').hidden = false;
  if (scroll) $('results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Veri uyarısı: iki takım da varsayılandaysa sonucun neden tek tip olduğunu açıkça söyler.
function dataWarning(h, a) {
  const hasH = hasProfile(h.name);
  const hasA = hasProfile(a.name);
  if (!hasH && !hasA) {
    return 'Bu iki takımın güç verisi girilmemiş. Tüm takımlar varsayılanda aynı değerle başladığı için sonuç, başka bir girilmemiş eşleşmeyle aynıdır. Gerçek fark için güç verisi girin.';
  }
  if (!hasH) return `${h.name} için güç verisi yok; varsayılan değer kullanılıyor.`;
  if (!hasA) return `${a.name} için güç verisi yok; varsayılan değer kullanılıyor.`;
  return '';
}

const pct = n => (n * 100).toFixed(1) + '%';

function renderResult({ h, a, m, s }) {
  $('resultTitle').innerHTML = `${escapeHtml(h.name)} <small>—</small> ${escapeHtml(a.name)}`;
  $('resultMeta').textContent = `90 dakika · Poisson olasılık matrisi · ${SIMULATIONS.toLocaleString('tr-TR')} örnekleme`;

  const warn = dataWarning(h, a);
  $('dataWarn').textContent = warn;
  $('dataWarn').hidden = !warn;

  $('homeProb').textContent = pct(m.hw);
  $('drawProb').textContent = pct(m.d);
  $('awayProb').textContent = pct(m.aw);
  $('homeBar').style.width = pct(m.hw);
  $('drawBar').style.width = pct(m.d);
  $('awayBar').style.width = pct(m.aw);

  let fav = 'Belirgin favori yok';
  if (m.hw - m.aw > 0.02) fav = `${h.name} daha yüksek galibiyet olasılığına sahip`;
  else if (m.aw - m.hw > 0.02) fav = `${a.name} daha yüksek galibiyet olasılığına sahip`;
  $('favoriteText').textContent = fav;

  $('expectedGoals').textContent = `${m.homeXg.toFixed(2)} – ${m.awayXg.toFixed(2)}`;
  $('mostLikely').textContent = m.scores[0].score;
  $('over25').textContent = pct(m.over25);

  $('scoreList').innerHTML = m.scores.slice(0, 6).map(x =>
    `<div class="score-chip"><strong>${x.score}</strong><span>${pct(x.p)}</span></div>`).join('');

  const stats = [
    ['Topla oynama', s.posH, s.posA, '%', 1],
    ['Toplam şut', s.shotsH, s.shotsA, '', 1],
    ['İsabetli şut', s.onH, s.onA, '', 1],
    ['Korner', s.cornersH, s.cornersA, '', 1],
    ['Faul', s.foulsH, s.foulsA, '', 1],
    ['Sarı kart', s.yellowH, s.yellowA, '', 2],
    ['Kırmızı kart', s.redH, s.redA, '', 3]
  ];
  $('statsTable').innerHTML = stats.map(([name, x, y, unit, dec]) => {
    const share = (x / ((x + y) || 1)) * 100;
    return `<div class="stat-row">
      <div class="stat-value">${x.toFixed(dec)}${unit}</div>
      <div class="stat-mid">
        <div class="stat-name">${name}</div>
        <div class="stat-track" aria-hidden="true"><span class="home-fill" style="width:${share}%"></span><span class="away-fill" style="width:${100 - share}%"></span></div>
      </div>
      <div class="stat-value right">${y.toFixed(dec)}${unit}</div>
    </div>`;
  }).join('');

  $('modelDetails').innerHTML = [
    ['Ev sahibi xG', m.homeXg.toFixed(3)],
    ['Deplasman xG', m.awayXg.toFixed(3)],
    ['Rating farkı (ev − dep.)', (m.hp.rating - m.ap.rating).toFixed(0)],
    ['Ev sahibi avantajı', m.homeAdv.toFixed(2) + '×'],
    ['Form etkisi', `${m.hp.form >= 0 ? '+' : ''}${m.hp.form} / ${m.ap.form >= 0 ? '+' : ''}${m.ap.form}`],
    ['Skor matrisi', '0–8 gol, normalize']
  ].map(([k, v]) => `<div class="model-item"><span>${k}</span><strong>${v}</strong></div>`).join('');
}

/* ---------- Dışa / içe aktarma ---------- */

function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportData() {
  const data = { format: 'futbol-lab-profiles-v1', exportedAt: new Date().toISOString(), profiles };
  download(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), 'futbol-lab-verileri.json');
}

// Tırnak içindeki virgülleri de doğru ayırır.
function splitCsvLine(line) {
  const out = [];
  let cur = '', quoted = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (quoted) {
      if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (c === '"') quoted = false;
      else cur += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { out.push(cur); cur = ''; }
    else cur += c;
  }
  out.push(cur);
  return out;
}

function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) throw new Error('CSV yalnızca başlık içeriyor ya da boş.');
  const header = splitCsvLine(lines.shift()).map(h => h.trim().toLowerCase());
  const nameCol = header.indexOf('team') !== -1 ? header.indexOf('team') : header.indexOf('name');
  if (nameCol === -1) throw new Error('CSV başlığında "team" sütunu yok.');
  return lines.map(line => {
    const cells = splitCsvLine(line);
    const row = {};
    header.forEach((k, i) => (row[k] = (cells[i] ?? '').trim()));
    return [(cells[nameCol] ?? '').trim(), row];
  }).filter(([name]) => name);
}

function parseJson(text) {
  const obj = JSON.parse(text);
  const map = obj && obj.profiles && typeof obj.profiles === 'object' ? obj.profiles : obj;
  if (!map || typeof map !== 'object' || Array.isArray(map)) throw new Error('JSON biçimi tanınmadı.');
  return Object.entries(map);
}

async function importData(e) {
  const file = e.target.files?.[0];
  e.target.value = '';
  if (!file) return;
  try {
    const text = (await file.text()).replace(/^\uFEFF/, '');
    const entries = file.name.toLowerCase().endsWith('.csv') ? parseCsv(text) : parseJson(text);
    let applied = 0;
    const missing = [];
    for (const [name, p] of entries) {
      const t = teamByName(name);
      if (t) { storeProfile(t.name, p); applied++; }
      else missing.push(name);
    }
    if (!applied) throw new Error('Dosyadaki takım adları listede bulunamadı.');
    saveProfiles();
    toast(`${applied} takımın güç verisi güncellendi${missing.length ? `, ${missing.length} ad listede yok` : ''}.`);
    if (!$('editor').hidden && editingName) openEditor(editingSide);
    if (!$('results').hidden) runMatch({ scroll: false, silent: true });
  } catch (err) {
    toast('Dosya okunamadı: ' + err.message);
  }
}

init();
