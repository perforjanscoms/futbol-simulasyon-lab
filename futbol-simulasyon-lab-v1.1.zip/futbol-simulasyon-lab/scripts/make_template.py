"""teams.json'dan güç şablonu (ratings-template.csv) üretir ve takım listesini doğrular.

Kullanım: python3 scripts/make_template.py
"""
import csv
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
teams = json.loads((ROOT / "teams.json").read_text(encoding="utf-8"))

clubs = [t for t in teams if t["type"] == "club"]
nationals = [t for t in teams if t["type"] == "national"]
names = [t["name"] for t in teams]
problems = []
if len(clubs) != 446:
    problems.append(f"kulüp sayısı {len(clubs)}, beklenen 446")
if len(nationals) != 209:
    problems.append(f"milli takım sayısı {len(nationals)}, beklenen 209")
if len(set(names)) != len(names):
    problems.append("tekrarlanan takım adı var")
if any(n != n.strip() or not n for n in names):
    problems.append("boş ya da boşluklu takım adı var")
if problems:
    sys.exit("Doğrulama hatası: " + "; ".join(problems))

with (ROOT / "ratings-template.csv").open("w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["team", "type", "rating", "attack", "defense", "form"])
    for t in teams:
        w.writerow([t["name"], t["type"], "", "", "", ""])

print(f"Tamam: {len(teams)} takım ({len(clubs)} kulüp, {len(nationals)} milli). ratings-template.csv yazıldı.")
